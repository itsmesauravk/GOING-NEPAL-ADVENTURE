import createTripsAndTours from "./sub-controller/createTripsAndTours.controller.js"
import getTripsAndTours from "./sub-controller/getTripsAndTours.controller.js"
import deleteTripsAndTours from "./sub-controller/deleteTripsAndTours.controller.js"

export { createTripsAndTours, getTripsAndTours, deleteTripsAndTours }
